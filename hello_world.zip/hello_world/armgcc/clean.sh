#!/bin/sh
rm -rf debug release CMakeFiles
rm -rf Makefile cmake_install.cmake CMakeCache.txt
